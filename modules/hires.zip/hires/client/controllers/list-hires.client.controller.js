(function () {
  'use strict';

  angular
  .module('hires')
  .controller('HiresListController', HiresListController)
  .filter('section', HiresSectionFilter)
  .filter('completed', CompletedFilter);


  function HiresSectionFilter() {
    return function(questions, sections) {

      var tempQuestions = [];
      angular.forEach(questions, function (question) {
        var allOK = true;
        console.log(sections);
        for (var section in sections) {
          console.log("-----");
          console.log(section);
          console.log(sections[section]);
          console.log(question[section]);
            if (sections[section].localeCompare(question[section]) != 0) {
              allOK = false;
              //break;
            }
          }
        if (allOK) {
          console.log("push");
          tempQuestions.push(question);
        }
      });
      return tempQuestions;
    };
  }


/*
  function HiresSectionFilter() {
    return function(questions, sections) {

      var tempQuestions = [];
      angular.forEach(questions, function (question) {
        var anyOK = false;
        for (var section in sections) {
          var currentOK = true;
            if (sections[section].localeCompare(question[section])) {
              currentOK = false;
              break;
            }
            anyOK |= currentOK;
          }
        if (anyOK) {
          tempQuestions.push(question);
        }
      });
      return tempQuestions;
    };
  }
*/

/*
  function HiresSectionFilter() {
    return function(questions, sections) {

      var tempQuestions = [];
      angular.forEach(questions, function (question) {
        var anyOK = false;
        for (var section in sections) {
          console.log(sections);
          console.log("2 " + section);
          console.log("3 " + prop);
          var currentOK = true;
            for (var prop in section) {
              console.log(sections[prop]);
              if (section[prop].localeCompare(question[prop])) {
                currentOK = false;
                break;
              }
            }
            anyOK |= currentOK;
          }
        if (anyOK) {
          tempQuestions.push(question);
        }
      });
      return tempQuestions;
    };
  }
*/

  function completed(question) {
    if (question.rating.ratingType === 'trueFalse') {
      return !!question.rating.trueFalse;
    } else {
      return question.rating.value > 0;
    }
  }

  function CompletedFilter() {
    return function(questions) {
      var tempQuestions = [];
      if (questions) {
        angular.forEach(questions, function (question) {
          if (completed(question)) {
            tempQuestions.push(question);
          }
        });
      }
      return tempQuestions;
    };
  }

  function SumOfFilter() {
    return function (data, key) {
        debugger;
        if (angular.isUndefined(data) && angular.isUndefined(key))
            return 0;
        var sum = 0;

        angular.forEach(data,function(v,k){
            sum = sum + parseInt(v[key]);
        });
        return sum;
    };
  }

  HiresListController.$inject = ['$scope', 'HiresService'];

  function HiresListController($scope, HiresService) {
    var vm = this;

    vm.addRow = function(questionText, ratingType) {

      vm.questions.push(
        {
          created: Date.now,
          user: 1,
          Interviewee: 2,
          question: questionText,
          section1: 'Hires',
          section2: 'Interview 1',
          section3: 'Knowledge',
          rating: {
            rated: false,
            ratingType: ratingType,
            trueFalse: null
          }
        }
      );
    };

    vm.currentQuestionType = function() {
      if (vm.currentSection.section1.localeCompare('Hires')) {
        return 'trueFalse';
      } else {
        return 'rating4';
      }
    }

    vm.currentModule = {section1:'Hires'};
    vm.currentUnit = {section1:'Hires', section2:'Interview 1'};
    vm.currentSection = {section1:'Hires', section2:'Interview 1', section3:'Knowledge'};

    vm.units = [
      {
        name: 'Interviews',
        value: [
          { section2:'Interview 1', section3:'Knowledge' },
          { section2:'Interview 1', section3:'Skills' },
          { section2:'Interview 1', section3:'Attitude' },
          { section2:'Interview 2', section3:'Knowledge' },
          { section2:'Interview 2', section3:'Skills' },
          { ection2:'Interview 2', section3:'Attitude' }
        ]
      },
      {
        name: 'Locations',
        value: [
          { section2:'Location 1', section3:'Knowledge' },
          { section2:'Location 2', section3:'Knowledge' }
        ]
      },
      {
        name: 'Checks',
        value: [
          { section2:'Checks', section3:'Knowledge' },
          { section2:'Checks', section3:'Skills' },
          { section2:'Checks', section3:'Attitude' }
        ]
      }
    ];

    vm.questions = [{
      created: Date.now,
      user: 1,
      Interviewee: 2,
      question: 'Works?',
      hint: "Hint?",
      section1: 'Hires',
      section2: 'Interview 1',
      section3: 'Knowledge',
      rating: {
        ratingType: 'rating4',
        value: 3
      }
    },
    {
      created: Date.now,
      user: 1,
      Interviewee: 2,
      question: 'Number 2?',
      section1: 'Hires',
      section2: 'Interview 1',
      section3: 'Knowledge',
      rating: {
        ratingType: 'rating4',
        value: 3
      }
    },
    {
      created: Date.now,
      user: 1,
      Interviewee: 2,
      question: 'Number 3?',
      section1: 'Hires',
      section2: 'Interview 1',
      section3: 'Knowledge',
      rating: {
        ratingType: 'rating4',
        value: 0
      }
    },
    {
      created: Date.now,
      user: 1,
      Interviewee: 2,
      question: 'Number 2?',
      section1: 'Hires',
      section2: 'Interview 2',
      section3: 'Knowledge',
      rating: {
        ratingType: 'rating4',
        value: 0
      }
    }
  ];

  }
}());
